<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContratoRenovacionPropietario extends Model
{
    //
}
