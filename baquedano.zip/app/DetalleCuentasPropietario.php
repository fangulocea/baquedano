<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleCuentasPropietario extends Model
{
    //
}
