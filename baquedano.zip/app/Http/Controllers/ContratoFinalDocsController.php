<?php

namespace App\Http\Controllers;

use App\ContratoFinalDocs;
use Illuminate\Http\Request;

class ContratoFinalDocsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ContratoFinalDocs  $contratoFinalDocs
     * @return \Illuminate\Http\Response
     */
    public function show(ContratoFinalDocs $contratoFinalDocs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ContratoFinalDocs  $contratoFinalDocs
     * @return \Illuminate\Http\Response
     */
    public function edit(ContratoFinalDocs $contratoFinalDocs)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ContratoFinalDocs  $contratoFinalDocs
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContratoFinalDocs $contratoFinalDocs)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ContratoFinalDocs  $contratoFinalDocs
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContratoFinalDocs $contratoFinalDocs)
    {
        //
    }
}
