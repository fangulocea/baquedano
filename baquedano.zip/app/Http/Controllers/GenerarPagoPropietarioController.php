<?php

namespace App\Http\Controllers;

use App\GenerarPagoPropietario;
use Illuminate\Http\Request;

class GenerarPagoPropietarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GenerarPagoPropietario  $generarPagoPropietario
     * @return \Illuminate\Http\Response
     */
    public function show(GenerarPagoPropietario $generarPagoPropietario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GenerarPagoPropietario  $generarPagoPropietario
     * @return \Illuminate\Http\Response
     */
    public function edit(GenerarPagoPropietario $generarPagoPropietario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GenerarPagoPropietario  $generarPagoPropietario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GenerarPagoPropietario $generarPagoPropietario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GenerarPagoPropietario  $generarPagoPropietario
     * @return \Illuminate\Http\Response
     */
    public function destroy(GenerarPagoPropietario $generarPagoPropietario)
    {
        //
    }
}
