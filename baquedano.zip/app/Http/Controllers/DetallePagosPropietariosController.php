<?php

namespace App\Http\Controllers;

use App\DetallePagosPropietarios;
use Illuminate\Http\Request;

class DetallePagosPropietariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DetallePagosPropietarios  $detallePagosPropietarios
     * @return \Illuminate\Http\Response
     */
    public function show(DetallePagosPropietarios $detallePagosPropietarios)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DetallePagosPropietarios  $detallePagosPropietarios
     * @return \Illuminate\Http\Response
     */
    public function edit(DetallePagosPropietarios $detallePagosPropietarios)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DetallePagosPropietarios  $detallePagosPropietarios
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetallePagosPropietarios $detallePagosPropietarios)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DetallePagosPropietarios  $detallePagosPropietarios
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetallePagosPropietarios $detallePagosPropietarios)
    {
        //
    }
}
