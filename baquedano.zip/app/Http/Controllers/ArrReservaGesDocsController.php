<?php

namespace App\Http\Controllers;

use App\ArrReservaGesDocs;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ArrReservaGesDocsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ArrReservaGesDocs  $arrReservaGesDocs
     * @return \Illuminate\Http\Response
     */
    public function show(ArrReservaGesDocs $arrReservaGesDocs)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ArrReservaGesDocs  $arrReservaGesDocs
     * @return \Illuminate\Http\Response
     */
    public function edit(ArrReservaGesDocs $arrReservaGesDocs)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ArrReservaGesDocs  $arrReservaGesDocs
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ArrReservaGesDocs $arrReservaGesDocs)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ArrReservaGesDocs  $arrReservaGesDocs
     * @return \Illuminate\Http\Response
     */
    public function destroy(ArrReservaGesDocs $arrReservaGesDocs)
    {
        //
    }
}
