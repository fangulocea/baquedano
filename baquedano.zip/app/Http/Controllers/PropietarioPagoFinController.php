<?php

namespace App\Http\Controllers;

use App\PropietarioPagoFin;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PropietarioPagoFinController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PropietarioPagoFin  $propietarioPagoFin
     * @return \Illuminate\Http\Response
     */
    public function show(PropietarioPagoFin $propietarioPagoFin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PropietarioPagoFin  $propietarioPagoFin
     * @return \Illuminate\Http\Response
     */
    public function edit(PropietarioPagoFin $propietarioPagoFin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PropietarioPagoFin  $propietarioPagoFin
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PropietarioPagoFin $propietarioPagoFin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PropietarioPagoFin  $propietarioPagoFin
     * @return \Illuminate\Http\Response
     */
    public function destroy(PropietarioPagoFin $propietarioPagoFin)
    {
        //
    }
}
