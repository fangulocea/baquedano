<?php

namespace App\Http\Controllers;

use App\PropietarioCuadratura;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PropietarioCuadraturaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PropietarioCuadratura  $propietarioCuadratura
     * @return \Illuminate\Http\Response
     */
    public function show(PropietarioCuadratura $propietarioCuadratura)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PropietarioCuadratura  $propietarioCuadratura
     * @return \Illuminate\Http\Response
     */
    public function edit(PropietarioCuadratura $propietarioCuadratura)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PropietarioCuadratura  $propietarioCuadratura
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PropietarioCuadratura $propietarioCuadratura)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PropietarioCuadratura  $propietarioCuadratura
     * @return \Illuminate\Http\Response
     */
    public function destroy(PropietarioCuadratura $propietarioCuadratura)
    {
        //
    }
}
