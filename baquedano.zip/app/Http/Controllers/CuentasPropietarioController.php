<?php

namespace App\Http\Controllers;

use App\CuentasPropietario;
use Illuminate\Http\Request;

class CuentasPropietarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CuentasPropietario  $cuentasPropietario
     * @return \Illuminate\Http\Response
     */
    public function show(CuentasPropietario $cuentasPropietario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CuentasPropietario  $cuentasPropietario
     * @return \Illuminate\Http\Response
     */
    public function edit(CuentasPropietario $cuentasPropietario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CuentasPropietario  $cuentasPropietario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CuentasPropietario $cuentasPropietario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CuentasPropietario  $cuentasPropietario
     * @return \Illuminate\Http\Response
     */
    public function destroy(CuentasPropietario $cuentasPropietario)
    {
        //
    }
}
