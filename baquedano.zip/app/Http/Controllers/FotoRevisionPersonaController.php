<?php

namespace App\Http\Controllers;

use App\FotoRevisionPersona;
use Illuminate\Http\Request;

class FotoRevisionPersonaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FotoRevisionPersona  $fotoRevisionPersona
     * @return \Illuminate\Http\Response
     */
    public function show(FotoRevisionPersona $fotoRevisionPersona)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FotoRevisionPersona  $fotoRevisionPersona
     * @return \Illuminate\Http\Response
     */
    public function edit(FotoRevisionPersona $fotoRevisionPersona)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FotoRevisionPersona  $fotoRevisionPersona
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FotoRevisionPersona $fotoRevisionPersona)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FotoRevisionPersona  $fotoRevisionPersona
     * @return \Illuminate\Http\Response
     */
    public function destroy(FotoRevisionPersona $fotoRevisionPersona)
    {
        //
    }
}
