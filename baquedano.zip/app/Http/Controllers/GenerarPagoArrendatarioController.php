<?php

namespace App\Http\Controllers;

use App\GenerarPagoArrendatario;
use Illuminate\Http\Request;

class GenerarPagoArrendatarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GenerarPagoArrendatario  $generarPagoArrendatario
     * @return \Illuminate\Http\Response
     */
    public function show(GenerarPagoArrendatario $generarPagoArrendatario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GenerarPagoArrendatario  $generarPagoArrendatario
     * @return \Illuminate\Http\Response
     */
    public function edit(GenerarPagoArrendatario $generarPagoArrendatario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GenerarPagoArrendatario  $generarPagoArrendatario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GenerarPagoArrendatario $generarPagoArrendatario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GenerarPagoArrendatario  $generarPagoArrendatario
     * @return \Illuminate\Http\Response
     */
    public function destroy(GenerarPagoArrendatario $generarPagoArrendatario)
    {
        //
    }
}
