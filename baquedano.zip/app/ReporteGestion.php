<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReporteGestion extends Model
{
    //
}
